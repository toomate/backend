create definer = root@localhost view vw_total_perda_validade as
select coalesce(sum((`l`.`precoUnit` * `l`.`quantidadeMedida`)), 0) AS `ValorTotalPerda`
from `toomate`.`lote` `l`
where (`l`.`dataValidade` < curdate());

