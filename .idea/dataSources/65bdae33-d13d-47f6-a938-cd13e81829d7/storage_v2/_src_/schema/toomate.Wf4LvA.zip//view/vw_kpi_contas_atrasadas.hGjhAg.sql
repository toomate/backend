create definer = root@localhost view vw_kpi_contas_atrasadas as
select count(0) AS `QtdAtrasadas`
from `toomate`.`boleto`
where ((`toomate`.`boleto`.`pago` = 0) and (`toomate`.`boleto`.`dataVencimento` < curdate()));

