create definer = root@localhost view vw_kpi_boletos_mes_atual as
select count(0) AS `QtdBoletosMes`
from `toomate`.`boleto`
where ((month(`toomate`.`boleto`.`dataVencimento`) = month(curdate())) and
       (year(`toomate`.`boleto`.`dataVencimento`) = year(curdate())));

