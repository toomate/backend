create definer = root@localhost view vw_total_entrada_estoque_semana as
select coalesce(sum((`l`.`precoUnit` * `l`.`quantidadeMedida`)), 0) AS `ValorTotalEntradas`
from `toomate`.`lote` `l`
where (yearweek(`l`.`dateEntrada`, 1) = yearweek(curdate(), 1));

