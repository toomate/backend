create definer = root@localhost view vw_pedido_aberto_mais_antigo as
select `c`.`nome`                                       AS `Cliente`,
       `d`.`dataCompra`                                 AS `dataCompra`,
       `d`.`valor`                                      AS `valor`,
       `d`.`pedido`                                     AS `pedido`,
       (to_days(curdate()) - to_days(`d`.`dataCompra`)) AS `DiasEmAberto`
from (`toomate`.`divida` `d` join `toomate`.`cliente` `c` on ((`d`.`fkCliente` = `c`.`idCliente`)))
where (`d`.`pago` = 0)
order by `d`.`dataCompra`
limit 1;

