create definer = root@localhost view vw_kpi_validade_proxima as
select `i`.`nome`                                         AS `Insumo`,
       `l`.`dataValidade`                                 AS `dataValidade`,
       `l`.`quantidadeMedida`                             AS `QtdAtual`,
       (to_days(`l`.`dataValidade`) - to_days(curdate())) AS `DiasParaVencer`
from ((`toomate`.`lote` `l` join `toomate`.`marca` `m` on ((`l`.`fkMarca` = `m`.`idMarca`))) join `toomate`.`insumo` `i`
      on ((`m`.`fkInsumo` = `i`.`idInsumo`)))
where (`l`.`dataValidade` <= (curdate() + interval 7 day));

