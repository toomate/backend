create definer = root@localhost view vw_kpi_estoque_baixo as
select `i`.`nome` AS `Insumo`, sum(`l`.`quantidadeMedida`) AS `EstoqueTotal`, `i`.`qtdMinima` AS `qtdMinima`
from ((`toomate`.`insumo` `i` left join `toomate`.`marca` `m`
       on ((`i`.`idInsumo` = `m`.`fkInsumo`))) left join `toomate`.`lote` `l` on ((`m`.`idMarca` = `l`.`fkMarca`)))
group by `i`.`idInsumo`, `i`.`nome`, `i`.`qtdMinima`
having ((`EstoqueTotal` <= `i`.`qtdMinima`) or (`EstoqueTotal` is null));

