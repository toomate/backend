create definer = root@localhost view vw_predicao_perda_validade as
select `i`.`nome`                                         AS `Insumo`,
       `l`.`quantidadeMedida`                             AS `QtdNoLote`,
       `l`.`dataValidade`                                 AS `dataValidade`,
       (to_days(`l`.`dataValidade`) - to_days(curdate())) AS `DiasRestantes`
from ((`toomate`.`lote` `l` join `toomate`.`marca` `m` on ((`l`.`fkMarca` = `m`.`idMarca`))) join `toomate`.`insumo` `i`
      on ((`m`.`fkInsumo` = `i`.`idInsumo`)))
where ((`l`.`dataValidade` > curdate()) and ((to_days(`l`.`dataValidade`) - to_days(curdate())) <= 5))
order by `l`.`quantidadeMedida` desc
limit 1;

