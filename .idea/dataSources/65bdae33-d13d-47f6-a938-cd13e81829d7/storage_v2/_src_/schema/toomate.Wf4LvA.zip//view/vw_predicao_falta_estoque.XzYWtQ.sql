create definer = root@localhost view vw_predicao_falta_estoque as
select `i`.`nome`                                      AS `Insumo`,
       sum(`l`.`quantidadeMedida`)                     AS `EstoqueAtual`,
       `i`.`qtdMinima`                                 AS `qtdMinima`,
       (sum(`l`.`quantidadeMedida`) - `i`.`qtdMinima`) AS `MargemSeguranca`
from ((`toomate`.`insumo` `i` join `toomate`.`marca` `m`
       on ((`i`.`idInsumo` = `m`.`fkInsumo`))) join `toomate`.`lote` `l` on ((`m`.`idMarca` = `l`.`fkMarca`)))
group by `i`.`idInsumo`, `i`.`nome`, `i`.`qtdMinima`
having (`EstoqueAtual` > 0)
order by `MargemSeguranca`
limit 1;

