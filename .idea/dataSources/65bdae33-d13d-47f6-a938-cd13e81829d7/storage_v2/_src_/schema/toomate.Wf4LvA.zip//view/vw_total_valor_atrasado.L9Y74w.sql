create definer = root@localhost view vw_total_valor_atrasado as
select coalesce(sum(`toomate`.`boleto`.`valor`), 0) AS `TotalDividaFornecedor`
from `toomate`.`boleto`
where ((`toomate`.`boleto`.`pago` = 0) and (`toomate`.`boleto`.`dataVencimento` < curdate()));

