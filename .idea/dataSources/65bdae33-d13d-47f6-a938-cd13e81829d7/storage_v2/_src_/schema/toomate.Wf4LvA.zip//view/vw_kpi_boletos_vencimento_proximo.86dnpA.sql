create definer = root@localhost view vw_kpi_boletos_vencimento_proximo as
select `toomate`.`boleto`.`idBoleto`       AS `idBoleto`,
       `toomate`.`boleto`.`descricao`      AS `descricao`,
       `toomate`.`boleto`.`categoria`      AS `categoria`,
       `toomate`.`boleto`.`pago`           AS `pago`,
       `toomate`.`boleto`.`dataVencimento` AS `dataVencimento`,
       `toomate`.`boleto`.`dataPagamento`  AS `dataPagamento`,
       `toomate`.`boleto`.`valor`          AS `valor`,
       `toomate`.`boleto`.`fkFornecedor`   AS `fkFornecedor`
from `toomate`.`boleto`
where ((`toomate`.`boleto`.`pago` = 0) and
       (`toomate`.`boleto`.`dataVencimento` between curdate() and (curdate() + interval 7 day)));

