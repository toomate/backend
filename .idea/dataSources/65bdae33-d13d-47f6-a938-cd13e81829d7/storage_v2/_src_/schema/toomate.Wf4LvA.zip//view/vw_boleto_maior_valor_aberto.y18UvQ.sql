create definer = root@localhost view vw_boleto_maior_valor_aberto as
select `toomate`.`boleto`.`idBoleto`       AS `idBoleto`,
       `toomate`.`boleto`.`descricao`      AS `descricao`,
       `toomate`.`boleto`.`categoria`      AS `categoria`,
       `toomate`.`boleto`.`pago`           AS `pago`,
       `toomate`.`boleto`.`dataVencimento` AS `dataVencimento`,
       `toomate`.`boleto`.`dataPagamento`  AS `dataPagamento`,
       `toomate`.`boleto`.`valor`          AS `valor`,
       `toomate`.`boleto`.`fkFornecedor`   AS `fkFornecedor`
from `toomate`.`boleto`
where (`toomate`.`boleto`.`pago` = 0)
order by `toomate`.`boleto`.`valor` desc
limit 1;

