create definer = root@localhost view vw_total_divida_clientes as
select coalesce(sum(`toomate`.`divida`.`valor`), 0) AS `TotalReceber`
from `toomate`.`divida`
where (`toomate`.`divida`.`pago` = 0);

