create definer = root@localhost view vw_grafico_estoque_vs_minimo as
select `i`.`nome`                                                                                                  AS `Insumo`,
       coalesce(sum(`l`.`quantidadeMedida`), 0)                                                                    AS `EstoqueAtual`,
       `i`.`qtdMinima`                                                                                             AS `EstoqueMinimo`,
       (case
            when (coalesce(sum(`l`.`quantidadeMedida`), 0) < `i`.`qtdMinima`) then 'Repor Urgente'
            else 'OK' end)                                                                                         AS `Status`
from ((`toomate`.`insumo` `i` left join `toomate`.`marca` `m`
       on ((`i`.`idInsumo` = `m`.`fkInsumo`))) left join `toomate`.`lote` `l` on ((`m`.`idMarca` = `l`.`fkMarca`)))
group by `i`.`idInsumo`, `i`.`nome`, `i`.`qtdMinima`;

