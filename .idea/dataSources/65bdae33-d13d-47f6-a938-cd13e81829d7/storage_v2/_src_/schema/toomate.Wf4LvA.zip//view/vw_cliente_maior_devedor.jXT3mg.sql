create definer = root@localhost view vw_cliente_maior_devedor as
select `c`.`nome` AS `nome`, `c`.`telefone` AS `telefone`, sum(`d`.`valor`) AS `TotalDevido`
from (`toomate`.`cliente` `c` join `toomate`.`divida` `d` on ((`c`.`idCliente` = `d`.`fkCliente`)))
where (`d`.`pago` = 0)
group by `c`.`idCliente`, `c`.`nome`, `c`.`telefone`
order by `TotalDevido` desc
limit 1;

