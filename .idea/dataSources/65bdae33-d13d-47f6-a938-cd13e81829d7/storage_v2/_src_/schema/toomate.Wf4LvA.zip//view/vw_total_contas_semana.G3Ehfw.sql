create definer = root@localhost view vw_total_contas_semana as
select coalesce(sum(`toomate`.`boleto`.`valor`), 0) AS `ValorTotalSemana`
from `toomate`.`boleto`
where (yearweek(`toomate`.`boleto`.`dataVencimento`, 1) = yearweek(curdate(), 1));

